﻿using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B12TestApp
{
    public partial class Form1 : Form
    {
        static IWebDriver driverFF;
        static FirefoxOptions options = new FirefoxOptions();
        IReadOnlyCollection<IWebElement> inputElements, AElements, ImgElements, SpanElements, LiElements;
        //static UInt16 b12Profile = 1;
        string elementstr;


        public Form1()
        {
            InitializeComponent();
            richTextBox1.Text = "Hoşgeldin,Tester..." + "\n" + "\n" + "Lütfen Testi Başlatmak için Test Başlat Butonuna basınız... ";

        }

        private async void test_baslat_btn_Click(object sender, EventArgs e)
        {

            Task task = Task.Run(() => PageLoadTest());
            await task;

        }

        public void PageLoadTest()
        {
            //****************************************************************
            //Firefox'da Pencere Aç Siteye Giriş Yap

            driverFF = new FirefoxDriver();
            driverFF.Navigate().GoToUrl("http://10.17.0.48/b12data");
            driverFF.Manage().Window.Maximize();
            driverFF.Manage().Timeouts().SetPageLoadTimeout(TimeSpan.FromSeconds(2));

            //****************************************************************
            //Tüm inputları Listele

            PageElements();

            foreach (IWebElement element in inputElements)
            {
                string elementstr;
                elementstr = element.GetAttribute("id");
                //richTextBox2.AppendText(elementstr + "\n");
                richTextBox2.Invoke(new MethodInvoker(delegate { richTextBox2.Text += elementstr+ "\n"; }));

            }
            if (richTextBox2.InvokeRequired)
            {

                RichTextBox temp=null;

                richTextBox2.Invoke(new MethodInvoker(delegate { temp = richTextBox2; 


                if (temp.Text == "")
                {
                    richTextBox3.Invoke(new MethodInvoker(delegate { richTextBox3.Text += "Page Loading Error" + "\n"; Application.DoEvents(); }));
                    
                     //TestStatusUpdate("Page Loading Error");
                }
                else if (temp.Find("kullanici") != -1)
                
                
                {

                    richTextBox3.Invoke(new MethodInvoker(delegate { richTextBox3.Text += "Page Has Been Succesfully Loaded" + "\n"; Application.DoEvents(); }));
                    richTextBox3.Invoke(new MethodInvoker(delegate { richTextBox3.Text += "Trying To Login" + "\n"; Application.DoEvents(); }));

                    //TestStatusUpdate("Page Has Been Succesfully Loaded");
                    //TestStatusUpdate("Trying To Login");
                    LoginTest_1();

                }
                }));

            }
           
        }


        public void LoginTest_1()
        {

            ////LOGIN TEST CASE 1-Kullanıcı Adı Yanlış Girişi

            foreach (IWebElement element in inputElements)
            {


                elementstr = element.GetAttribute("id");

                try
                {

                    if (elementstr == "kullanici")
                    {
                        element.SendKeys("AAAA");
                    }
                    else if (elementstr == "Sifre")
                    {
                        element.SendKeys("12345A");
                        element.Submit();
                        Thread.Sleep(2000);


                        PageElements();
                        foreach (IWebElement lielement in LiElements)
                        {

                            string lielementstr;

                            lielementstr = lielement.Text;

                            //IReadOnlyCollection<IWebElement> aaa = driverFF.FindElements(By.XPath("/html/body/div/div[3]/form/div/div[4]/div[4]/ul/li"));

                            //richTextBox2.AppendText(aaa + "\n");

                            if (lielementstr == "Kullanıcı tanımlı değil.")
                            {
                                TestStatusUpdate("Yanlış Kullanıcı Testi Başarılı"); 

                                break;
                            }


                        }

                        PageElements();
                        richTextBox2.Text = "";
                        LoginTest2();
                        break;
                    }


                }
                catch
                {
                    MessageBox.Show("LoginTest 1 Başarısız");
                }

            }

        }

        public void LoginTest2()
        {

            driverFF.FindElement(By.Id("kullanici")).Clear();
            driverFF.FindElement(By.Id("Sifre")).Clear();

            Thread.Sleep(3000);

            foreach (IWebElement element in inputElements)
            {

                elementstr = element.GetAttribute("ID");


                try
                {


                    if (elementstr == "kullanici")
                    {
                        element.SendKeys("MASTER");
                    }
                    else if (elementstr == "Sifre")
                    {
                        element.SendKeys("12345A");
                        element.Submit();
                        Thread.Sleep(2000);
                        PageElements();
                        richTextBox2.Text = "";
                        SwitchSolutionTest();
                        break;
                    }


                }
                catch
                {
                    MessageBox.Show("LoginTest2 Başarısız");
                }

            }

        }

        public void SwitchSolutionTest()
        {
            //IWebElement baglanbtn = null;

            //foreach (IWebElement element in inputElements)
            //{
            //    elementstr = element.GetAttribute("id");

            //    try
            //    {
            //        if (elementstr == null)
            //        {
            //            element.Click();
            //            element.Submit();
            //        }


            //    }

            //    catch
            //    {
            //        MessageBox.Show("SwitchSolutionTest Başarısız");
            //    }

            //}

            //XPATH Değiştirilecek//
            IWebElement SwitchInput = driverFF.FindElement(By.XPath("/html/body/div/div[2]/form/div[1]/div/div[2]/h3"));
            OpenQA.Selenium.Interactions.Actions builder = new OpenQA.Selenium.Interactions.Actions(driverFF);
            builder.MoveToElement(driverFF.FindElement(By.XPath("/html/body/div/div[2]/form/div[1]/div/div[2]/h3"))).Click().Build().Perform();

            //Bağlan Butonuna Bas
            IWebElement connectInput = driverFF.FindElement(By.Id("baglan"));
            connectInput.SendKeys(OpenQA.Selenium.Keys.Enter);

            Thread.Sleep(2000);

            //**************************************************PERSONEL MENÜ**********************************************************************************


            IWebElement PersonelMenuInput = driverFF.FindElement(By.XPath("/html/body/div[2]/div[3]/div[1]/div/div[1]/div[2]/div/ul/li[1]/div/span[2]/span"));
            OpenQA.Selenium.Interactions.Actions builder2 = new OpenQA.Selenium.Interactions.Actions(driverFF);
            builder2.MoveToElement(driverFF.FindElement(By.XPath("/html/body/div[2]/div[3]/div[1]/div/div[1]/div[2]/div/ul/li[1]/div/span[2]/span"))).DoubleClick().Build().Perform();

            Thread.Sleep(2000);


            IWebElement PersonelMenu2Input = driverFF.FindElement(By.XPath("/html/body/div[2]/div[3]/div[1]/div/div[1]/div[2]/div/ul/li[1]/ul/li[1]/div/span/span"));
            OpenQA.Selenium.Interactions.Actions builder3 = new OpenQA.Selenium.Interactions.Actions(driverFF);
            builder3.MoveToElement(driverFF.FindElement(By.XPath("/html/body/div[2]/div[3]/div[1]/div/div[1]/div[2]/div/ul/li[1]/ul/li[1]/div/span/span"))).DoubleClick().Build().Perform();

            Thread.Sleep(2000);

            //**************************************************PERSONEL MENÜ-IFRAME IN**********************************************************************************

            //driver.SwitchTo().Frame(0);


            //IWebElement iFrame = driver.SwitchTo().Frame(driver.FindElement(By.Id("tabIframe1"))); 

            //IWebElement PersonelAddInput = driver.FindElement(By.Id("grid_insert"));
            //OpenQA.Selenium.Interactions.Actions builder4 = new OpenQA.Selenium.Interactions.Actions(driver);
            //builder4.MoveToElement(driver.FindElement(By.Id("grid_insert"))).Click().Build().Perform();

            //driver.SwitchTo().DefaultContent();

            Thread.Sleep(2000);


            //**************************************************PERSONEL MENÜ-IFRAME OUT**********************************************************************************



            //driver.FindElement(By.XPath("//input[@value='Individual']")).Click();
            //driver.FindElement(By.Id("grid_insert")).Submit();
            //**************************************************************************************************************************************            

            driverFF.Close();
        }
        public void TestStatusUpdate(string statusString)
        {
            if (richTextBox3.InvokeRequired)
            {

                richTextBox3.Invoke(new MethodInvoker(delegate { richTextBox3.Text += statusString + "\n"; }));
                Application.DoEvents();
                
            }

            else
            {
                //richTextBox3.Text += statusString + "\n";
                richTextBox3.Invoke(new MethodInvoker(delegate { richTextBox3.Text += statusString + "\n"; }));
                Application.DoEvents();
            }
        }

        public void PageElements()
        {
            inputElements = driverFF.FindElements(By.TagName("input"));
            AElements = driverFF.FindElements(By.TagName("a"));
            ImgElements = driverFF.FindElements(By.TagName("img"));
            SpanElements = driverFF.FindElements(By.TagName("span"));
            //LiElements = driverFF.FindElements(By.CssSelector("li"));
            LiElements = driverFF.FindElements(By.TagName("div"));
        }


    }
}
