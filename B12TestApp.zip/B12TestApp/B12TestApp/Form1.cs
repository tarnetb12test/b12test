﻿using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B12TestApp
{
    public partial class Form1 : Form
    {
        static IWebDriver driverFF;
        static FirefoxOptions options = new FirefoxOptions();
        IReadOnlyCollection<IWebElement> inputElements;
        //static UInt16 b12Profile = 1;

        public Form1()
        {
            InitializeComponent();
            richTextBox1.Text = "Hoşgeldin,Tester..." + "\n" + "\n" + "Lütfen Testi Başlatmak için Test Başlat Butonuna basınız... ";

        }

        private void test_baslat_btn_Click(object sender, EventArgs e)
        {
            LoginTest();
        }

        public void LoginTest()
        {
            //****************************************************************
            //Firefox'da Pencere Aç Siteye Giriş Yap

            driverFF = new FirefoxDriver();
            driverFF.Navigate().GoToUrl("http://10.17.0.48/b12data");
            driverFF.Manage().Window.Maximize();
            driverFF.Manage().Timeouts().SetPageLoadTimeout(TimeSpan.FromSeconds(2));

            //****************************************************************
            //Tüm inputları Listele

            PageElements();

            foreach (IWebElement element in inputElements)
            {
                string elementstr;
                elementstr = element.GetAttribute("id");
                richTextBox2.AppendText(elementstr + "\n");

            }
            if (richTextBox2.Text == "")
            {
                TestStatusUpdate("Page Loading Error");
            }
            else if (richTextBox2.Find("kullanici") != -1)
            {
                TestStatusUpdate("Page Has Been Succesfully Loaded");
                TestStatusUpdate("Trying To Login");
                SwitchSolutionTest();

            }
        }

        ////LOGIN TEST CASE 1-Kullanıcı Adı Yanlış Girişi

        public void SwitchSolutionTest()
        {



            foreach (IWebElement element in inputElements)
            {
                string elementstr;

                elementstr = element.GetAttribute("id");

                try
                {
                    if (elementstr == "kullanici")
                    {
                        element.SendKeys("AAAA");
                    }
                    else if (elementstr == "Sifre")
                    {
                        element.SendKeys("12345A");
                        element.Submit();
                        Thread.Sleep(2000);
                        break;
                        
                    }
                }
                catch 
                { 
                   
                }

                PageElements();
                richTextBox2.Text = "";


            }


            //****************************************************************

            //try
            //{


            //    IWebElement FalseInput = driverFF.FindElement(By.Id("kullanici"));
            //    FalseInput.SendKeys("AAAA");

            //    Giriş Butonuna Bas
            //    FalseInput.SendKeys(OpenQA.Selenium.Keys.Enter);

            //    driverFF.FindElement(By.Id("kullanici")).Clear();

            //    Thread.Sleep(2000);
            //}

            //catch (Exception e)
            //{

            //}


            //****************************************************************
            //Kullanıcı Adı Doğru Girişi

            driverFF.FindElement(By.Id("kullanici")).Clear();

            IWebElement searchInput = driverFF.FindElement(By.Id("kullanici"));
            searchInput.SendKeys("MASTER");


            //Şifre Girişi
            IWebElement PassInput = driverFF.FindElement(By.Id("Sifre"));
            PassInput.SendKeys("12345A");


            //Giriş Butonuna Bas
            searchInput.SendKeys(OpenQA.Selenium.Keys.Enter);

            Thread.Sleep(2000);

            //XPATH Değiştirilecek//
            IWebElement SwitchInput = driverFF.FindElement(By.XPath("/html/body/div/div[2]/form/div[1]/div/div[2]/h3"));
            OpenQA.Selenium.Interactions.Actions builder = new OpenQA.Selenium.Interactions.Actions(driverFF);
            builder.MoveToElement(driverFF.FindElement(By.XPath("/html/body/div/div[2]/form/div[1]/div/div[2]/h3"))).Click().Build().Perform();

            //Bağlan Butonuna Bas
            IWebElement connectInput = driverFF.FindElement(By.Id("baglan"));
            connectInput.SendKeys(OpenQA.Selenium.Keys.Enter);

            Thread.Sleep(2000);

            //**************************************************PERSONEL MENÜ**********************************************************************************


            IWebElement PersonelMenuInput = driverFF.FindElement(By.XPath("/html/body/div[2]/div[3]/div[1]/div/div[1]/div[2]/div/ul/li[1]/div/span[2]/span"));
            OpenQA.Selenium.Interactions.Actions builder2 = new OpenQA.Selenium.Interactions.Actions(driverFF);
            builder2.MoveToElement(driverFF.FindElement(By.XPath("/html/body/div[2]/div[3]/div[1]/div/div[1]/div[2]/div/ul/li[1]/div/span[2]/span"))).DoubleClick().Build().Perform();

            Thread.Sleep(2000);


            IWebElement PersonelMenu2Input = driverFF.FindElement(By.XPath("/html/body/div[2]/div[3]/div[1]/div/div[1]/div[2]/div/ul/li[1]/ul/li[1]/div/span/span"));
            OpenQA.Selenium.Interactions.Actions builder3 = new OpenQA.Selenium.Interactions.Actions(driverFF);
            builder3.MoveToElement(driverFF.FindElement(By.XPath("/html/body/div[2]/div[3]/div[1]/div/div[1]/div[2]/div/ul/li[1]/ul/li[1]/div/span/span"))).DoubleClick().Build().Perform();

            Thread.Sleep(2000);

            //**************************************************PERSONEL MENÜ-IFRAME IN**********************************************************************************

            //driver.SwitchTo().Frame(0);


            //IWebElement iFrame = driver.SwitchTo().Frame(driver.FindElement(By.Id("tabIframe1"))); 

            //IWebElement PersonelAddInput = driver.FindElement(By.Id("grid_insert"));
            //OpenQA.Selenium.Interactions.Actions builder4 = new OpenQA.Selenium.Interactions.Actions(driver);
            //builder4.MoveToElement(driver.FindElement(By.Id("grid_insert"))).Click().Build().Perform();

            //driver.SwitchTo().DefaultContent();

            Thread.Sleep(2000);


            //**************************************************PERSONEL MENÜ-IFRAME OUT**********************************************************************************



            //driver.FindElement(By.XPath("//input[@value='Individual']")).Click();
            //driver.FindElement(By.Id("grid_insert")).Submit();
            //**************************************************************************************************************************************            

            //driver.Close();
        }

        public void TestStatusUpdate(string statusString)
        {
            richTextBox3.AppendText(statusString + "\n");
        }


        public void PageElements()
        {
            inputElements = driverFF.FindElements(By.TagName("input"));

        }


    }
}
